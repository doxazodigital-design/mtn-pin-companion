package ng.mtn.pincompanion;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.telephony.TelephonyManager.UssdResponseCallback;
import android.widget.*;
import android.view.View;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
  EditText endpoint, token; TextView state; Button fetch,send,dial,mark;
  String pin=""; int pinId=-1; boolean initiated=false;
  Handler ui=new Handler(Looper.getMainLooper());
  @Override public void onCreate(Bundle b){super.onCreate(b);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,30,24,24);
    ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
    TextView title=new TextView(this);title.setText("MTN PIN Companion • Test version");title.setTextSize(22);root.addView(title);
    endpoint=new EditText(this);endpoint.setHint("https://your-domain.com/pinloader/api.php");endpoint.setSingleLine(true);root.addView(endpoint);
    token=new EditText(this);token.setHint("Private 64-character phone token");token.setSingleLine(true);root.addView(token);
    android.content.SharedPreferences prefs=getPreferences(0);
    endpoint.setText(prefs.getString("url",""));token.setText(prefs.getString("token",""));
    state=new TextView(this);state.setText("No PIN claimed. Make sure your MTN SIM is used for calls/USSD.");state.setPadding(0,12,0,16);root.addView(state);
    fetch=button(root,"1. Fetch ONE queued PIN");send=button(root,"2. Send USSD (manual tap)");dial=button(root,"Fallback: Open phone dialler");mark=button(root,"3. Mark uncertain / manual review");
    send.setEnabled(false);dial.setEnabled(false);mark.setEnabled(false);
    fetch.setOnClickListener(v->{prefs.edit().putString("url",endpoint.getText().toString().trim()).putString("token",token.getText().toString().trim()).apply();request("claim",new JSONObject(),false);});
    send.setOnClickListener(v->issueUssd());
    dial.setOnClickListener(v->{ if(pinId<0)return; initiated=true;Intent it=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode("*474*"+pin+"#")));startActivity(it);state.setText("Dialler opened. Confirm the MTN result, then mark uncertain for review. Dialler launch is NOT proof of credit.");send.setEnabled(false);});
    mark.setOnClickListener(v->report("manual","Manual check needed. Verify actual MTN result in portal."));
  }
  Button button(LinearLayout r,String s){Button b=new Button(this);b.setText(s);r.addView(b);return b;}
  void note(String s){ui.post(()->state.setText(s));}
  void request(String action,JSONObject data, boolean result){
    try {data.put("action",action);}catch(Exception e){};
    new Thread(()->{
      HttpURLConnection c=null;
      try {
        String address=endpoint.getText().toString().trim();
        if(!address.startsWith("https://"))throw new IOException("HTTPS address required");
        c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(12000);
        c.setRequestMethod("POST");c.setRequestProperty("X-Device-Token",token.getText().toString().trim());c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);
        try(OutputStream o=c.getOutputStream()){o.write(data.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[1024];int n;while((n=stream.read(buffer))!=-1)out.write(buffer,0,n);
        JSONObject response=new JSONObject(out.toString("UTF-8"));
        if(code>=400)throw new IOException("Server HTTP "+code+": "+response.optString("error"));
        if(!result && response.optString("state").equals("ready")){
          String nextPin=response.getString("pin");int nextId=response.getInt("id");
          ui.post(()->{pin=nextPin;pinId=nextId;initiated=false;state.setText("PIN #"+pinId+" (ending "+pin.substring(Math.max(0,pin.length()-4))+") ready. Tap Send USSD once.");send.setEnabled(true);dial.setEnabled(true);mark.setEnabled(true);fetch.setEnabled(false);});
        } else if(result) {
          ui.post(()->{state.setText("Recorded as: "+response.optString("status")+". Verify MTN balance before classifying success.");pin="";pinId=-1;initiated=false;send.setEnabled(false);dial.setEnabled(false);mark.setEnabled(false);fetch.setEnabled(true);});
        } else note("Queue: "+response.optString("state")+" "+response.optString("message"));
      }catch(Exception e){note("Connection issue: "+e.getMessage()+". Do NOT resend any PIN automatically.");}
      finally {if(c!=null)c.disconnect();}
    }).start();
  }
  void issueUssd(){
    if(pinId<0 || initiated)return;
    if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CALL_PHONE},1);return;}
    initiated=true;send.setEnabled(false);dial.setEnabled(false);note("Sending USSD once; waiting for MTN response…");
    try {
      TelephonyManager tm=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
      tm.sendUssdRequest("*474*"+pin+"#",new UssdResponseCallback(){
        @Override public void onReceiveUssdResponse(TelephonyManager t,String request,CharSequence response){report("network",response.toString());}
        @Override public void onReceiveUssdResponseFailed(TelephonyManager t,String request,int failureCode){report("error","Android USSD error "+failureCode+"; recharge outcome not verified");}
      },ui);
    } catch(Exception e){note("Android blocked USSD: "+e.getMessage()+". Open dialler for manual test or mark for review. Do not resend blindly.");dial.setEnabled(true);}
  }
  void report(String kind,String message){
    if(pinId<0)return;
    JSONObject j=new JSONObject();try{j.put("id",pinId);j.put("kind",kind);j.put("message",message);}catch(Exception e){}
    note("MTN/phone response: "+message+"\nRecording result…");request("result",j,true);
  }
}
