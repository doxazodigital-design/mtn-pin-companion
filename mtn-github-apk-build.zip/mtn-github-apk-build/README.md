# Build the MTN PIN Companion APK via GitHub Actions (no Android Studio)

This archive contains the **Android app source only** plus a GitHub Actions workflow. It does NOT contain an APK. The PHP `api.php` from the previous companion project is still needed on your cPanel server.

1. Create a GitHub account at https://github.com if you do not have one.
2. Create a new **private** repository, e.g. `mtn-pin-companion`.
3. Upload the contents of this extracted folder into the repository root, preserving `.github/workflows/build-apk.yml`, `android-app/app/build.gradle`, etc. Note: `.github` starts with a dot and can be hidden in your file browser. The workflow MUST appear at `.github/workflows/build-apk.yml` in GitHub, not nested inside an extra folder.
4. In your repository on GitHub, open **Actions**, select **Build Android APK**, then **Run workflow**.
5. When the workflow completes successfully, click its run and download the **MTN-PIN-Companion-APK** artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Transfer the APK to your Infinix Note 30, open it and allow installation from that source only for the install. Turn the install permission off afterward.
7. Set up your PHP API and token as instructed in the original Android companion project's README. **Do not put secrets or real PINs in GitHub**. Turn off the old cron worker.
8. Start with a safe non-recharge connection test, then verify carrier approval and manually test just one unused low-value PIN. The app needs you to tap each PIN. A dialer launch or gateway callback is not proof of airtime credit.

This project has not been compiled by us: the GitHub workflow is intended to perform the build. GitHub Actions may have account and usage limits; public/private repository visibility and minutes quotas can vary.

If you see build errors, open the failed step in GitHub Actions and copy the error text (not secrets) for debugging.
